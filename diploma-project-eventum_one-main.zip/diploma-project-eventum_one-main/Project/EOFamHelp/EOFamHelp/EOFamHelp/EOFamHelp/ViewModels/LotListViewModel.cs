﻿using EOFamHelp.Data.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EOFamHelp.ViewModels 
{
    public class LotListViewModel
    {
        public IEnumerable<Lot> Lots { get; set; }
        public SelectList LotTypes { get; set; } 
        public string Name { get; set; }
    }
}
