﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EOFamHelp.ViewModels
{
    public class LotModel
    {
        public int LotTypeId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
        public double MinPrice { get; set; }
        public double TempPrice { get; set; }

        public double Decline { get; set; }

        public string Path { get; set; }
        public DateTime Created { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public IFormFile Avatar { get; set; }
        public int Age { get; set; }

        public bool End { get; set; }
       
      


    }
}
