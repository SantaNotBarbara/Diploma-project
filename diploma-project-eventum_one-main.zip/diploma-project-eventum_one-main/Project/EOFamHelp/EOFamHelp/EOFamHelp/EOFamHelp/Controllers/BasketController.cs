﻿using EOFamHelp.Data;
using EOFamHelp.Data.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EOFamHelp.Controllers
{
    public class BasketController : Controller
    {
        private ApplicationContext db;
        public BasketController(ApplicationContext context)
        {
            db = context;
        }
        public async Task<IActionResult> UserProfile(int? id) 
        {

            if (id != null)
            {
                User user = await db.Users.FirstOrDefaultAsync(p => p.UserId == id);
                if (user != null)
                    return View(user);
            }
            return NotFound();
        }
        public async Task<IActionResult> Index()
        {
           
            var user = db.Users.FirstOrDefault(p => p.Email == User.Identity.Name);

            return View(db.Lots.Where(p=>  (p.BasketUserId == user.UserId && p.End == true ) || (p.BasketUserId == user.UserId && DateTime.Now > p.EndTime)).ToList());
        }


    }
}