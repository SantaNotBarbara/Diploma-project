﻿using EOFamHelp.Data;
using EOFamHelp.Data.Models;
using EOFamHelp.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EOFamHelp.Controllers
{
    
    public class EventController : Controller
    {
        private readonly ILogger<EventController> _logger;
        public ApplicationContext db;
         IWebHostEnvironment _appEnvironment;
        public EventController(ILogger<EventController> logger, ApplicationContext applicationContext, IWebHostEnvironment appEnvironment)
        {
            db = applicationContext;
            _logger = logger;
            _appEnvironment = appEnvironment;

        }

        public async Task<IActionResult> Event() 
        {


            return View(await db.Events.ToListAsync());
         
        }
        public async Task<IActionResult> Index()
        {


             return View(await db.Events.ToListAsync());
           
        }
        public IActionResult Create()
        {
            return View();
        }
        public IActionResult Admin()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(EventModel eventModel)
        {

            if (eventModel.Avatar != null)
            {
                // путь к папке Files
                string path = "/Files/" + eventModel.Avatar.FileName;
                // сохраняем файл в папку Files в каталоге wwwroot
                using (var fileStream = new FileStream(_appEnvironment.WebRootPath + path, FileMode.Create))
                {
                    await eventModel.Avatar.CopyToAsync(fileStream);
                }
              
                Event file = new Event
                {
                   Name = eventModel.Name,
                   Description = eventModel.Description,
                   Start = eventModel.Start,
                   End = eventModel.End,
                
                    Path = path
                };
                db.Events.Add(file);
                db.SaveChanges();
            }

            return RedirectToAction("Event");
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id != null)
            {
                Event @event = await db.Events.FirstOrDefaultAsync(p => p.Id == id);
                if (@event != null)
                    return View(@event);
            }
            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> Edit(Event @event)
        {
          
            db.Events.Update(@event);
            await db.SaveChangesAsync();
            return RedirectToAction("Event");
        }



        [HttpGet]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id != null)
            {
                Event @event = await db.Events.FirstOrDefaultAsync(p => p.Id == id);
                if (@event != null)
                {
                    db.Events.Remove(@event);
                    await db.SaveChangesAsync();
                    return RedirectToAction("Index");
                }
            }
            return NotFound();
        }
    }
}
