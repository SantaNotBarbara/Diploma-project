﻿using EOFamHelp.Data;
using EOFamHelp.Data.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Linq;

namespace EOFamHelp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        public ApplicationContext db;
        public HomeController(ILogger<HomeController> logger, ApplicationContext applicationContext)
        {


            _logger = logger;

        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Faq()
        {
            return View();
        }
        public IActionResult Howtobuyinauction() 
        {
            return View();
        }
        public IActionResult Howtosell() 
        {
            return View();
        }
        public IActionResult Donation()
        {
            return View();
        }
        public IActionResult How()
        {
            return View();
        }
        public IActionResult Contactpage()
        {
            return View();
        }
        public IActionResult Vacancy()
        {
            return View();
        }
        public IActionResult Team()
        {
            return View();
        }
        public IActionResult History()
        {
            return View();
        }
        public IActionResult Beneficiaries()
        {
            return View();
        }
        [Authorize(Roles = "admin")]
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}