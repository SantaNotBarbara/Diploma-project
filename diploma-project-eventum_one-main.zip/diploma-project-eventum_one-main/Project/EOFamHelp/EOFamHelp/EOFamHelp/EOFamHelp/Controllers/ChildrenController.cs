﻿using EOFamHelp.Data;
using EOFamHelp.Data.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EOFamHelp.Controllers
{
    [Authorize]
    public class ChildrenController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        public ApplicationContext db;
        public ChildrenController(ILogger<HomeController> logger, ApplicationContext applicationContext)
        {
            db = applicationContext;
            _logger = logger;

        }

        public async Task<IActionResult> Child() 
        {   
            
            User user = db.Users.Where(p => p.Email == User.Identity.Name).FirstOrDefault();
            return View(await db.Children.Where(p => p.UserId == user.UserId).ToListAsync());
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(Children child)
        {
            User user = db.Users.Where(p => p.Email == User.Identity.Name).FirstOrDefault();
            child.Created = DateTime.Now;
            child.UserId = user.UserId;
            db.Children.Add(child);
            await db.SaveChangesAsync();
            return RedirectToAction("Child");
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id != null)
            {
                Children child = await db.Children.FirstOrDefaultAsync(p => p.Id == id);
                if (child != null)
                    return View(child);
            }
            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> Edit(Children child)
        {   
            User user = db.Users.Where(p => p.Email == User.Identity.Name).FirstOrDefault();
            child.Created = DateTime.Now;
            child.UserId = user.UserId;
            db.Children.Update(child);
            await db.SaveChangesAsync();
            return RedirectToAction("Child");
        }



        [HttpGet]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id != null)
            {
                Children child = await db.Children.FirstOrDefaultAsync(p => p.Id == id);
                if (child != null)
                {
                    db.Children.Remove(child);
                    await db.SaveChangesAsync();
                    return RedirectToAction("Child");
                }
            }
            return NotFound();
        }

    }
}
