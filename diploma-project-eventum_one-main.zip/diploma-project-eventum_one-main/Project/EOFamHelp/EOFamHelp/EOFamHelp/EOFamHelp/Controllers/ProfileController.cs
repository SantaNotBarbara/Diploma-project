﻿using EOFamHelp.Data;
using EOFamHelp.Data.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EOFamHelp.Controllers
{
    [Authorize]
    public class ProfileController : Controller
    {
        private readonly ILogger<ProfileController> _logger;
        public ApplicationContext db;
        public ProfileController(ILogger<ProfileController> logger, ApplicationContext applicationContext)
        {
            db = applicationContext;
             _logger = logger;

        }
        public async Task<IActionResult> Profile() 
        {

             User user = await db.Users.Where(p => p.Email ==User.Identity.Name ).FirstOrDefaultAsync();
             return View( user);
            
        }


        public async Task<IActionResult> Edit()
        {

            User user = await db.Users.Where(p => p.Email == User.Identity.Name).FirstOrDefaultAsync();

            return View(user);
           
        }
        [HttpPost]
        public async Task<IActionResult> Edit(User user)
        {
            User temp = db.Users.Where(p => p.Email == User.Identity.Name).First();
            temp.FirstName = user.FirstName;
            temp.LastName= user.LastName;
            temp.Password = user.Password;
            temp.PhoneNumber = user.PhoneNumber;
            db.Users.Update(temp);
            await db.SaveChangesAsync();
            return RedirectToAction("Profile");
        }
    }


}
