﻿using EOFamHelp.Data;
using EOFamHelp.Data.Models;
using EOFamHelp.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EOFamHelp.Controllers
{
    [Authorize]
    public class LotController : Controller
    {
        private readonly ILogger<LotController> _logger;
        public ApplicationContext db;
        IWebHostEnvironment _appEnvironment;
        
        public LotController(ILogger<LotController> logger, ApplicationContext applicationContext, IWebHostEnvironment appEnvironment )
        {
           
            db = applicationContext; 
            _logger = logger;
            _appEnvironment = appEnvironment;
            if (db.LotTypes.Count() == 0)
            { 
                LotType lotType1 = new LotType { Name = "Одежда для мальчиков" };
                LotType lotType2 = new LotType { Name = "Oдежда для девочек" };
                LotType lotType3 = new LotType { Name = "Игрушка для мальчиков" };
                LotType lotType4 = new LotType { Name = "Игрушка для девочек" };
                db.LotTypes.AddRange(lotType1 , lotType2 , lotType3, lotType4);
                db.SaveChanges();
            }
        }
         
        public IActionResult Main(int? lottype, string name)
        {
            IQueryable<Lot> lots = db.Lots.Include(p => p.LotType);
            if (lottype != null && lottype != 0)
            {
                lots = lots.Where(p => p.LotTypeId == lottype);
            }
            if (!String.IsNullOrEmpty(name))
            {
                lots = lots.Where(p => p.Name.Contains(name));
            }

            List<LotType> companies = db.LotTypes.ToList();
            // устанавливаем начальный элемент, который позволит выбрать всех
            companies.Insert(0, new LotType { Name = "Все", Id = 0 });

            LotListViewModel viewModel = new LotListViewModel
            { 
                Lots = lots.ToList(),
                LotTypes = new SelectList(companies, "Id", "Name"),
                Name = name
            };
            return View(viewModel);

        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id != null)
            {
                Lot lot = await db.Lots.FirstOrDefaultAsync(p => p.LotId == id);
                if (lot != null)
                    return View(lot);
            }
            return NotFound();
        }
       

        public IActionResult Index()
        {
        
            return View ();
        
        }
        public IActionResult Sellinglots()
        {
            User user = db.Users.Where(p => p.Email == User.Identity.Name).FirstOrDefault();
            return View(db.Lots.Where(p=> p.LotUserId == user.UserId).ToList());

        }
        [HttpPost]
        public async Task<IActionResult> AddLot(LotModel lotModel)
        { 
            if (lotModel.Avatar!= null)
            {
                // путь к папке Files
                string path = "/Files/" + lotModel.Avatar.FileName;
                // сохраняем файл в папку Files в каталоге wwwroot
                using (var fileStream = new FileStream(_appEnvironment.WebRootPath + path, FileMode.Create))
                {
                    await lotModel.Avatar.CopyToAsync(fileStream);
                }
                User user = await db.Users.Where(p => p.Email == User.Identity.Name).FirstOrDefaultAsync();
                Lot file = new Lot { Name = lotModel.Name, Description = lotModel.Description, Decline = lotModel.Decline, 
                    MinPrice =lotModel.MinPrice ,  Price = lotModel.Price,TempPrice = lotModel.Price, 
                    End = false , Age = lotModel.Age, LotTypeId = lotModel.LotTypeId, 
                    StartTime = lotModel.StartTime ,
                    EndTime = lotModel.EndTime ,LotUserId = user.UserId, Path = path };
                db.Lots.Add(file);
                db.SaveChanges();
            }

            return RedirectToAction("Index");
        }
        [HttpGet]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id != null)
            {
                Lot lot = await db.Lots.FirstOrDefaultAsync(p => p.LotId == id);
                if (lot != null)
                {
                    db.Lots.Remove(lot);
                    await db.SaveChangesAsync();
                    return RedirectToAction("Index");
                }
            }
            return NotFound();
        }
    }
}
