﻿using EOFamHelp.Data;
using EOFamHelp.Data.Models;
using EOFamHelp.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EOFamHelp.Controllers
{
   
    public class DonationController : Controller
    {
        private readonly ILogger<DonationController> _logger;
        public ApplicationContext db; 
        IWebHostEnvironment _appEnvironment;
        public DonationController(ILogger<DonationController> logger, ApplicationContext applicationContext, IWebHostEnvironment appEnvironment)
        {
            db = applicationContext;
            _logger = logger;
            _appEnvironment = appEnvironment;
        }

        public async Task<IActionResult> Donation()
        {


            return View(await db.Donations.ToListAsync());
         
        }
        public async Task<IActionResult> Index()
        {


            return View(await db.Donations.ToListAsync());
        
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(DonationModel donationModel)
        {
            if (donationModel.Avatar != null)
            {
                // путь к папке Files
                string path = "/Files/" + donationModel.Avatar.FileName;
                // сохраняем файл в папку Files в каталоге wwwroot
                using (var fileStream = new FileStream(_appEnvironment.WebRootPath + path, FileMode.Create))
                {
                    await donationModel.Avatar.CopyToAsync(fileStream);
                }

               Donation file = new Donation
                {
                    Name = donationModel.Name,
                    Description = donationModel.Description,
                    BigDescription = donationModel.BigDescription,
                   

                    Path = path
                };
                db.Donations.Add(file);
                db.SaveChanges();
            }
            
            return RedirectToAction("Donation");
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id != null)
            {
                Donation donations = await db.Donations.FirstOrDefaultAsync(p => p.DonationId == id);
                if (donations != null)
                    return View(donations);
            }
            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> Edit(Donation donation)
        {

            db.Donations.Update(donation);
            await db.SaveChangesAsync();
            return RedirectToAction("Donation");
        }



        [HttpGet]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id != null)
            {
                Donation donation = await db.Donations.FirstOrDefaultAsync(p => p.DonationId == id);
                if (donation != null)
                {
                    db.Donations.Remove(donation);
                    await db.SaveChangesAsync();
                    return RedirectToAction("Donation");
                }
            }
            return NotFound();
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id != null)
            {
                var donat = await db.Donations.FirstOrDefaultAsync(p => p.DonationId == id);
                if (donat != null)
                    return View(donat);
            }
            return NotFound();
        }

    }
}
