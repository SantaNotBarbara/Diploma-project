const addFavBtn = document.querySelector(".add-fav-wrapper");

const addFavSvg = document.querySelector(".add-fav");

const path1 = document.querySelector(".path1");

addFavBtn.addEventListener("click", () => {
     addFavSvg.classList.toggle("added-to-fav");

     path1.classList.toggle("new-path1");
});