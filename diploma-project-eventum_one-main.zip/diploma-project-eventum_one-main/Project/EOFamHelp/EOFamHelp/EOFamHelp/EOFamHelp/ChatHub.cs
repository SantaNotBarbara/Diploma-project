﻿using EOFamHelp.Data;
using EOFamHelp.Data.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EOFamHelp
{
    [Authorize]
    public class ChatHub : Hub
    {
        public ApplicationContext db;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public ChatHub(ApplicationContext applicationContext, IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            db = applicationContext;
            
        }
        string groupname;
   
        public async Task Enter( string gName)
        {
            
            groupname = gName;
            int c =  Int32.Parse(gName);
            var username12 = _httpContextAccessor.HttpContext.User.Identity.Name;
            var user = db.Users.FirstOrDefault(p => p.Email == username12);
            Lot lot = db.Lots.First(p => p.LotId == c);
            if (lot.LotUserId == user.UserId) {

                await Clients.Caller.SendAsync("Notify", " " + "Это ваш товар");
            }
            else if (DateTime.Now < lot.StartTime) {
                await Clients.Caller.SendAsync("Notify", " " + "Аукцион еще не начался");
            }
            else if (DateTime.Now > lot.EndTime || lot.End == true)
            {
                await Clients.Caller.SendAsync("Notify", " " + "Аукцион закончился");
            }
            else if (lot.BasketUserId != user.UserId)
            {



                var children = db.Children.Where(p => p.UserId == user.UserId);
                int[] ages = new int[children.Count()];
                int i = 0;
                foreach (var child in children) {

                ages[i] = (DateTime.Now.Year - child.BirthDate.Year);
                i++;

                }
                
                if (ages.Contains(lot.Age))
                {
                    
                    lot.TempPrice = lot.TempPrice - lot.Decline;
                    lot.BasketUserId = user.UserId;
                    if (lot.TempPrice < lot.MinPrice)
                    {
                        lot.TempPrice = lot.TempPrice + lot.Decline;
                        lot.End = true;
                    }
                    else if (lot.TempPrice == lot.MinPrice) {
                        lot.End = true;
                    }
                    lot.Click = lot.Click+ 1;
                    db.Update(lot);
                    db.SaveChanges();
                    
                    await Groups.AddToGroupAsync(Context.ConnectionId, groupname);
                    await Clients.Group(groupname).SendAsync("Receive",   lot.TempPrice.ToString()+ " ₸");
                    await Clients.Group(groupname).SendAsync("Notify", "Текущая цена " + lot.TempPrice.ToString() + " ₸");
                    await Clients.Caller.SendAsync("Receive", lot.TempPrice.ToString()  + " ₸");
                    await Clients.Caller.SendAsync("Notify", "Ваша цена " + lot.TempPrice.ToString() + " ₸");
                }
                else {
                    await Clients.Caller.SendAsync("Notify", "Возраст не подходит");
                }
            }
            else
            {
                await Clients.Caller.SendAsync("Notify", " " + "Вы уже предложили цену");
            }
        }
        }
       
 }

