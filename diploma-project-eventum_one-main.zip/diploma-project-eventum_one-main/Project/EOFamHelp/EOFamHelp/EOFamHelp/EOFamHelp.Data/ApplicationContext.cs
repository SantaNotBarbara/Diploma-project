﻿using EOFamHelp.Data.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EOFamHelp.Data
{
    public class ApplicationContext : DbContext
    {  
        public DbSet<User> Users { get; set; }
      //  public DbSet<Auction> Auctions { get; set; }
        public DbSet<Children> Children { get; set; }
        public DbSet<City>  Cities { get; set; }
      //  public DbSet<Customer> Customers { get; set; }
        public DbSet<Lot> Lots { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<LotType> LotTypes { get; set; }

        public DbSet<Role> Roles { get; set; }

        public DbSet<Donation> Donations { get; set; }

        public ApplicationContext(DbContextOptions<ApplicationContext> options)
            : base(options)
        {
            Database.EnsureCreated();
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Lot>()
                        .HasOne(x => x.LotUser).WithMany(x => x.MyLots).HasForeignKey(x => x.LotUserId);
             
            modelBuilder.Entity<Lot>()
                        .HasOne(x => x.BasketUser).WithMany(x => x.BasketLots).HasForeignKey(x => x.BasketUserId);

            string adminRoleName = "admin";
            string userRoleName = "user";

            string adminEmail = "admin@mail.ru";
            string adminPassword = "123456";

            // добавляем роли
            City city = new City { CityId = 1 , Name = "Алматы" };
            Role adminRole = new Role { Id = 1, Name = adminRoleName };
            Role userRole = new Role { Id = 2, Name = userRoleName };
            User adminUser = new User { UserId = 1, Email = adminEmail, Password = adminPassword, RoleId = adminRole.Id , CityId = 1 };
            modelBuilder.Entity<City>().HasData(new City[] { city });
            modelBuilder.Entity<Role>().HasData(new Role[] { adminRole, userRole });
            modelBuilder.Entity<User>().HasData(new User[] { adminUser });
            base.OnModelCreating(modelBuilder);

        }

    }
}
