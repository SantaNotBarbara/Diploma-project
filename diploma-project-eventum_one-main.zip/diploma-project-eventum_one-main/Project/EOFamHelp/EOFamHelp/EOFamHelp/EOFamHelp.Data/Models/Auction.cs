﻿using System.ComponentModel.DataAnnotations.Schema;

namespace EOFamHelp.Data.Models
{
    public class Auction
    {
        public int AuctionId { get; set; } 
        public double Price { get; set; }

      
        public int LotId { get; set; }
        public Lot Lot { get; set; }

        public int CustomerId { get; set; }
        public Customer Customer { get; set; }

    }
}
