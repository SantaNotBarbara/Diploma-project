﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EOFamHelp.Data.Models
{
    public class Children
    {
        public int Id { get; set; }
      
        public string FirstName { get; set; }
      
        public DateTime BirthDate { get; set; }
        public DateTime Created { get; set; }
        
        public bool Updated { get; set; } // true or false

        public int UserId { get; set; } 
        public User User { get; set; }


    }
}
