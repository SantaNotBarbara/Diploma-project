﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EOFamHelp.Data.Models
{
    public class Donation
    {
        public int DonationId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string BigDescription { get; set; }
         
        public string Path { get; set; }

       
       

    }
}
