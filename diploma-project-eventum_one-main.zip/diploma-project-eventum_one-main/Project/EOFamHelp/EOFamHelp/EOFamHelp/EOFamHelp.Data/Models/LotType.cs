﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EOFamHelp.Data.Models
{
    public class LotType
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public List<Lot> Lots { get; set; }
        public LotType()
        {
            Lots = new List<Lot>();
        }


    }
}
