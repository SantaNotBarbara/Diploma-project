﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace EOFamHelp.Data.Models
{
    public class Customer
    {
        public int CustomerId { get; set; }
        public List<Auction> Auctions { get; set; }

        [ForeignKey(nameof(User))]
        public int UserId { get; set; }
        public User User { get; set; }

    }
}
