﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EOFamHelp.Data.Models
{
    public class Lot
    { 
        [Key]
        public int LotId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
        public double MinPrice { get; set; }
        public double TempPrice { get; set; }

        public double Decline { get; set; } 
        public string Path { get; set; }
        public DateTime Created { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
      //  public Auction Auctions { get; set; }
        public int Click { get; set; } 
        public int Age { get; set; }
         
        public bool End { get; set; }

        public int LotTypeId { get; set; }
        public LotType LotType { get; set; }

        public int? LotUserId { get; set; }
        public int? BasketUserId { get; set; } 

        public virtual User LotUser { get; set; }
        public virtual User BasketUser { get; set; }

    }
}
