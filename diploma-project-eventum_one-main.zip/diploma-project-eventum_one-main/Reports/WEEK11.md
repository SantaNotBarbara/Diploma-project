# Ulan Orazaly (Project Manager)
* Creating help desk. Checking the system of using tools and tasks.	
![ulanweek11report](https://user-images.githubusercontent.com/98660924/161530692-63c38448-323f-431a-96d6-e4e5016412e9.jpeg)
![ulanweek11report1](https://user-images.githubusercontent.com/98660924/161531223-fad35229-847a-40ba-9132-4bc805723207.jpeg)
![ulanweek11report2](https://user-images.githubusercontent.com/98660924/161531510-3f34e1f2-0145-45e5-a709-13329b58f76a.jpeg)
![ulanweek11report3](https://user-images.githubusercontent.com/98660924/161532358-06f73b9f-0f53-4086-a86b-0d54e9b3789c.jpeg)

# Bekzat Nauryzbayev (Backend Developer)
Development of a product catalogue and reverse auction system
![image](https://user-images.githubusercontent.com/81714787/161532595-44b72b91-78b7-4757-9f2c-27828680f9f4.png)
![image](https://user-images.githubusercontent.com/81714787/161532782-2df0281f-9174-4015-8d54-aee1a661c6c5.png)

# Meiirlan Serikbay (Full-stack Developer)
* Developing a controller for charity events
![week11reportcharitycontroller](https://user-images.githubusercontent.com/98660924/161444281-94de3498-d7b1-4f97-a5ef-83aaafd5b8e4.png)
Charity event page
![Screenshot_charityeventspage](https://user-images.githubusercontent.com/98660924/166225059-96ae3816-089b-4c5e-9014-2ab8da7e8d4d.png)

# Kamilla Nurgozhayeva (Ui/Ux Designer)
Created a page for the auction itself And category page

![image](https://user-images.githubusercontent.com/46282086/161520625-6b6437d7-c194-46c8-9f6e-3198bb16513e.png)




# Rustem Bairamov (Frontend Developer)
Created auction page designed by Kamilla
![image](https://user-images.githubusercontent.com/47534213/166267784-7f751fea-96d0-4e08-aced-15f4e8237f3e.png)
