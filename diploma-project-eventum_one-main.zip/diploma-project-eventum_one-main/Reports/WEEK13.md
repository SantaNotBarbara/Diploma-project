# Ulan Orazaly (Project Manager)
Checking the project for functionality and work done to date. Setting goals and action plan for further development.

# Bekzat Nauryzbayev (Backend Developer)
Developing a basket controller.
![Снимок экрана (2492)](https://user-images.githubusercontent.com/81714787/166309477-35ba72ed-7932-4a1b-ba46-2b9f3bbec60f.png)

# Meiirlan Serikbay (Full-stack Developer)
Checked whether the Authorize attribute has been applied, bug check. 
![Screenshot_authattributeweek13](https://user-images.githubusercontent.com/98660924/164990238-1c83ccf6-16f7-4138-b282-3e1a1ce42364.png)
Created Contact us page
![Screenshot_contactusweek13](https://user-images.githubusercontent.com/98660924/164990720-834bf429-6741-48dc-b1eb-8f99a79584d7.png)
![Screenshot_contactusweek131](https://user-images.githubusercontent.com/98660924/164990739-e006584b-5b4c-4153-b02f-14e1714e0650.png)

# Kamilla Nurgozhayeva (Ui/Ux Designer)
Made prototype. There were people who are ready to participate in the interview. Made an appointment for the weekend (23th and 24th april)
![image](https://user-images.githubusercontent.com/46282086/163725421-496cf1d3-14c2-43ed-8a65-3731fdb702c0.png)


# Rustem Bairamov (Frontend Developer)
Created support page, favourite lots
![image](https://user-images.githubusercontent.com/47534213/166266364-fca6a9d7-1898-41d9-8b2e-6d38775ef9a7.png)
![image](https://user-images.githubusercontent.com/47534213/166266502-c9691237-29c2-4cc4-9691-8d2fa6c49c59.png)
