# Ulan Orazaly (Project Manager)
* An online meeting was held with the team for the further development and action plan of our team, as well as what has been done so far. Next, initial sketches were made for the introduction of tasks and their implementation. There was a selection of a suitable web platform for the implementation of a project management system. Also online-meeting was recorded online and posted on YouTube: https://www.youtube.com/watch?v=h15Ci2UOPpw

![WhatsApp Image 2022-02-28 at 17 50 18](https://user-images.githubusercontent.com/98660924/156002650-c1cb5f3b-c8bd-4e78-b31e-fcac50505e77.jpeg)
![WhatsApp Image 2022-03-05 at 16 01 35](https://user-images.githubusercontent.com/98660924/156878584-cdcc6453-02ae-4860-b2af-065729ed57f2.jpeg)


# Bekzat Nauryzbayev (Backend Developer)
* Developing a database in MSSQL, thinking through the tables of their entities and relationships. Database diagram.

![Screenshot_бд2](https://user-images.githubusercontent.com/98660924/156011368-e86b20b6-a1d4-4ffd-91e0-362a29d3390e.png)
![Screenshot_бд](https://user-images.githubusercontent.com/98660924/156010810-b5c2b90c-69ce-4603-bdf8-4a1490cfee37.png)
# Meiirlan Serikbay (Full-stack Developer)
* Project development in .NET 5, setting up the Startup class.

![Screenshot_proje](https://user-images.githubusercontent.com/98660924/156012428-b56e18eb-e799-4222-9e94-5a6cc3da6ce7.png) 

![Screenshot_proje3](https://user-images.githubusercontent.com/98660924/156001036-c0975a2b-5e49-4a0b-a6ee-06c6571ddf0a.png)

# Kamilla Nurgozhayeva (Ui/Ux Designer)
* Created the main page of the site by using Figma. Started designed sign in page
* Link to prototype
* https://www.figma.com/file/vxp9PqUePmNfQPeZohp8nM/FAM-HELP?node-id=98%3A16076
![image](https://user-images.githubusercontent.com/46282086/155977828-b4d0e819-dd75-4882-b632-d213142cfdff.png)
![image](https://user-images.githubusercontent.com/46282086/155977865-4d0f2889-8213-4e96-9a07-742176465935.png)
![image](https://user-images.githubusercontent.com/46282086/155977889-b2d24029-8e25-44ac-9395-9da41d6fcf03.png)
![image](https://user-images.githubusercontent.com/46282086/155977925-54ff09a9-370a-4f8b-b58d-85cc319a6224.png)
![image](https://user-images.githubusercontent.com/46282086/155977955-b2cfd344-6ba3-456a-aec6-95f98ff5ebcd.png)

# Bairamov Rustem (Frontend Developer)
* Consulted with the designer about the design of the main page, what can be implemented and what not

![image](https://user-images.githubusercontent.com/46282086/155977828-b4d0e819-dd75-4882-b632-d213142cfdff.png)
![image](https://user-images.githubusercontent.com/46282086/155977865-4d0f2889-8213-4e96-9a07-742176465935.png)
![image](https://user-images.githubusercontent.com/46282086/155977889-b2d24029-8e25-44ac-9395-9da41d6fcf03.png)
![image](https://user-images.githubusercontent.com/46282086/155977925-54ff09a9-370a-4f8b-b58d-85cc319a6224.png)
![image](https://user-images.githubusercontent.com/46282086/155977955-b2cfd344-6ba3-456a-aec6-95f98ff5ebcd.png)
