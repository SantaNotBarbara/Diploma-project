# Ulan Orazaly (Project Manager)
* Online meeting with team to discuss our progress. Mindmaps for project.
* https://youtu.be/rJFkTq_opgM
![ulanorazalyreportweek10](https://user-images.githubusercontent.com/98660924/160387241-e0099e05-8fa9-4a89-b03e-81fd86f17a60.jpeg)
![ulanweek10report](https://user-images.githubusercontent.com/98660924/160390050-46ebf9c3-0c75-4953-93e1-c0e77d67dad2.jpeg)
![ulanweek10report](https://user-images.githubusercontent.com/98660924/161530210-8d30336a-e2c9-43dd-a0a7-d41657a39024.jpeg)


# Bekzat Nauryzbayev (Backend Developer)
* Development of adding, editing, lots and deleting.
* ![Снимок экрана (2278)](https://user-images.githubusercontent.com/81714787/160386062-656dbe3c-6aee-42d9-93d8-011fd0e166ed.png)

# Meiirlan Serikbay (Full-stack Developer)
* Developing a donation.
![Screenshot_week10report1](https://user-images.githubusercontent.com/98660924/165485055-14703cdf-483b-4c89-9e16-cdbaf60b1ce8.png)
![Screenshot_week10report2](https://user-images.githubusercontent.com/98660924/165485065-0b6de00e-0b83-48b1-a3d1-81290b0b6359.png)

# Kamilla Nurgozhayeva (Ui/Ux Designer)
* Created a logo. 
![image](https://user-images.githubusercontent.com/46282086/160374412-23233b7f-f962-4be1-8b57-4fd1fe4c1a0b.png)

For clarity to the people of Kazakhstan, we decided to choose the Russian language. Therefore, some changes have been made. All content has been translated into Russian.
![image](https://user-images.githubusercontent.com/46282086/160374362-ac975baf-c74a-4293-b9e0-6706d0c39c96.png)
Changes have been made to the children page. It was decided to remove the photo and surname of the children from the profile, leaving the name and date of birth.

![image](https://user-images.githubusercontent.com/46282086/160378324-aa01d6b7-495f-4f9b-85ac-4f61a121b052.png)



# Rustem Bairamov (Frontend Developer)
* Created Child Page and Add Child page
![image](https://user-images.githubusercontent.com/47534213/160377522-1cebf236-06aa-4d3a-bdee-723058c71dff.png)
![image](https://user-images.githubusercontent.com/47534213/160377564-8f737b9e-d001-4d90-a762-7dfc3c0e37bf.png)
