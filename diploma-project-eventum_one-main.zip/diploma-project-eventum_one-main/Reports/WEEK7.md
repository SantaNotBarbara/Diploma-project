# Ulan Orazaly (Project Manager)
Checking the architecture of a web application by criteria:
- Efficiency
- Flexibility
- Expandability
- Compliance with the principle of open-closed
- Development process scalability
- Easy to check
- Reusability
- Well structured and readable code
- Bottom line

The correctness of the tasks. Troubleshooting in the initial stages of development and further instructions for elimination, improvement. The specific process of problem solving used in this unit was adapted from an eighth-grade technology textbook written for New York State standard technology curriculum.

![problem_spiralbyUlanOrazaly](https://user-images.githubusercontent.com/98660924/156881145-677e56d8-8322-441d-ad23-b8b47f6de8e3.jpg)
![ulan7weekreportsend](https://user-images.githubusercontent.com/98660924/158157508-2ff789b5-4c2e-4347-b432-6fe568271c1e.jpeg)
# Bekzat Nauryzbayev (Backend Developer)
* I thought about the architecture of the project.

I decided to use a three-layer architecture . Patterns : repository , UnitOfWork .

Added dependencies between layers. 

Presentation layer : This is the layer that the user directly interacts with. This level includes the user interface components, the mechanism for receiving input from the user. In relation to mvc, at this level, there are views and all those components that make up the user interface (styles, static html, javascript pages), as well as view models, controllers, request context objects.

Business layer : contains a set of components that are responsible for processing the data received from the presentation layer, implements all the necessary application logic, all calculations, interacts with the database and passes the processing result to the presentation layer.

Data Access layer : stores models that describe the entities used, also specific classes for working with different data access technologies are placed here, for example, the Entity Framework data context class. It also stores the repositories through which the business logic layer interacts with the database.
![Снимок экрана (2194)](https://user-images.githubusercontent.com/81714787/156873505-56430745-6fd8-478b-acd4-2d2582b88ec0.png)
![Снимок экрана (2193)](https://user-images.githubusercontent.com/81714787/156873552-a2b38627-ba3c-4eb3-aab1-185098416fa8.png)
![Снимок экрана (2195)](https://user-images.githubusercontent.com/81714787/156873578-7eb971e3-35de-44b5-9488-ad7dbbe4eb8b.png)


# Meiirlan Serikbay (Full-stack Developer)
* Bootstrap connection. Setting up home pages and routing between them. Adding a project layout to bootstrap and setting up pages.

![Screenshot_FAMHELP3](https://user-images.githubusercontent.com/98660924/156787168-793b1a67-4074-4862-a0e8-e4a7e5f1f9e1.png)
![Screenshot_FAMHELP](https://user-images.githubusercontent.com/98660924/156787075-576c1e19-7ba3-4c2c-a301-21d28dd83cf4.png)
![Screenshot_FAMHELP2](https://user-images.githubusercontent.com/98660924/156787153-53b7a3b3-ca57-4bb7-8e46-780931a52737.png)

# Kamilla Nurgozhayeva (Ui/Ux Designer)
* Creating a profile registration page and start profile page itself. Here is a screenshot of registration page
* ![image](https://user-images.githubusercontent.com/46282086/156875580-039d9434-f0b9-4a97-90c4-5191c9bec0fc.png)

# Rustem Bairamov (Frontend Developer)
* Created main page designed by Kamilla![site3](https://user-images.githubusercontent.com/47534213/156880944-512d0d04-b278-4dea-8676-319bf192506c.png)
![site4](https://user-images.githubusercontent.com/47534213/156880947-597ea759-12d9-4adf-91aa-4c5f7449db5c.png)
![site1](https://user-images.githubusercontent.com/47534213/156880950-8b3d0e37-2c5c-4c9b-b0f6-59e92fa511fa.png)
![site2](https://user-images.githubusercontent.com/47534213/156880955-1bd568d1-9da8-4889-ab52-ce281358ec1f.png)

