# Ulan Orazaly (PM) 
* Development of a plan for a further project. Writing process of the proposal and title of the project.
# Bekzat Nauryzbayev(Backend Dev)
* Get to know my teammates and discuss the choice of technology stack and language choice.
# Meiirlan Serikbay (Fullstack Dev)
* I prepared for the presentation of the project
# Kamilla Nurgozhayeva (Ui/Ux Designer)
* Created a moodboard. It contains photos that will be on the site, a palette and a main font.
* ![image](https://user-images.githubusercontent.com/46282086/156811975-050adccb-84e6-462c-82d8-675bf2f32bbe.png)

# Rustem Bairamov (Frontend Dev)
* I created user stories and user personas for the project
