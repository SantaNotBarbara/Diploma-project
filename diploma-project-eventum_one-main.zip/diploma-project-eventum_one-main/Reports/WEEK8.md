# Ulan Orazaly (Project Manager)
* Checking the completion of tasks. Registration and fixing of all assigned tasks in the board using the Kanban / Scrum method. Control at all stages of development. Online meeting with the team to discuss what has been done / what needs to be done / and what problems there are at the moment.
* https://youtu.be/b9uLMc4U5Kw
![ulan8weekreport](https://user-images.githubusercontent.com/98660924/158159069-6bc7c649-d4b4-43c8-95a3-5332f226d3f4.jpeg)

# Bekzat Nauryzbayev (Backend Developer)
* Packages connected  Microsoft.EntityFrameworkCore.SqlServer и Microsoft.AspNetCore.Identity.EntityFrameworkCore  .
  The approach was taken by "Code First " .
  Added data models and links between them .
![bekzatweek8report](https://user-images.githubusercontent.com/98660924/158162354-c20a602f-d060-4667-ac96-316d71d997d0.png)

# Meiirlan Serikbay (Full-stack Developer)
* Connecting pages for registration and personal profile to the web application.
![Screenshot_8weekreport](https://user-images.githubusercontent.com/98660924/158156571-c0a14c48-3769-40fb-994e-cdf8c5d566f6.png)

# Kamilla Nurgozhayeva (Ui/Ux Designer)
* Created profile page. 
![image](https://user-images.githubusercontent.com/46282086/158150956-70614f00-b054-4947-97b3-2bc7ff05e717.png)
![image](https://user-images.githubusercontent.com/46282086/158151055-99b9b9e1-1ab6-473b-9735-bb293c214247.png)
![image](https://user-images.githubusercontent.com/46282086/158151879-423aaeb2-de28-4b1a-9826-df907503abeb.png)
 
* Created a page for the lot. Developed the logic and rules of the anti-auction.

![image](https://user-images.githubusercontent.com/46282086/158154580-e99186f7-a19d-4dc7-86ac-08bb74b48145.png)
![image](https://user-images.githubusercontent.com/46282086/158154620-48d4fd31-46b8-4bd2-b599-2aef2cb61afc.png)
![image](https://user-images.githubusercontent.com/46282086/158154674-2f096cad-b869-448b-aec1-53afe45bd2ee.png)

# Rustem Bairamov (Frontend Developer)
* Created pages for registration and personal profile designed by Kamilla
![Screenshot_8weekreport](https://user-images.githubusercontent.com/98660924/158156571-c0a14c48-3769-40fb-994e-cdf8c5d566f6.png)
![profile1](https://user-images.githubusercontent.com/47534213/158160631-ee32996a-ce93-4956-9002-e4f14bb25f23.png)
![profile2](https://user-images.githubusercontent.com/47534213/158160661-3ecbe81d-2043-43ff-97c5-e11881e9d14b.png)
![image](https://user-images.githubusercontent.com/47534213/158162331-a1eeaa23-d041-4546-8439-cf9e908d456b.png)
![registration](https://user-images.githubusercontent.com/47534213/158160679-4601b8ed-0577-42a0-9fae-d6ad1190e7c3.png)


