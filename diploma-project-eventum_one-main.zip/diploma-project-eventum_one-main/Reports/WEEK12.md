# Ulan Orazaly (Project Manager)
Starting working on documentation. Discussion on chapters.
![ulanreportweek12 (1)](https://user-images.githubusercontent.com/98660924/166257872-c0a4bd87-d106-4657-9c2d-c718cad2c54c.jpeg)
![ulanreportweek12 (2)](https://user-images.githubusercontent.com/98660924/166257899-7f665966-7099-48a0-a305-3a84a5e3eacd.jpeg)
![ulanreportweek12 (3)](https://user-images.githubusercontent.com/98660924/166257904-d770b2c3-4176-4950-8540-b4a937037dc6.jpeg)

# Bekzat Nauryzbayev (Backend Developer)
Developing delivery and communication between seller and customer
![image](https://user-images.githubusercontent.com/81714787/166309000-0a779e70-b80c-4c1c-88d3-903e705a4b13.png)

# Meiirlan Serikbay (Full-stack Developer)
* Creating How to help, Who got help pages
![Screenshot_howtohelppage](https://user-images.githubusercontent.com/98660924/166224568-6cebef21-f8b0-4d21-974a-f020c838b593.png)
![Screenshot_whogotgelppage](https://user-images.githubusercontent.com/98660924/166224576-67518e25-f0a8-463c-acc0-4f24c1f8cc7f.png)

# Kamilla Nurgozhayeva (Ui/Ux Designer)
Created pages: about us, contacts, team, our story, details, vacancies.

![image](https://user-images.githubusercontent.com/46282086/163655073-591a6787-ca5f-43cc-b320-04298f808725.png)

# Rustem Bairamov (Frontend Developer)
Created a donation page
![image](https://user-images.githubusercontent.com/47534213/166267608-f30bf1d6-636d-4324-8a7d-519539acf281.png)
![image](https://user-images.githubusercontent.com/47534213/166267634-f0b9a4ae-58e1-4ddd-82f2-1eae68a013d9.png)
