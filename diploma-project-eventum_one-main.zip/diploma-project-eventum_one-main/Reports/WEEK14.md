# Ulan Orazaly (Project Manager)

# Bekzat Nauryzbayev (Backend Developer)
Developing the admin panel
![Снимок экрана (2493)](https://user-images.githubusercontent.com/81714787/166309937-64f427ae-929e-4514-b71f-8b151cb93f68.png)


# Meiirlan Serikbay (Full-stack Developer)
Connecting the frontend layout to the web application. Creating Our story, Our team, Settings, FAQ pages
![Screenshot_ourstorypage](https://user-images.githubusercontent.com/98660924/166224102-f0847ae9-267a-4006-90f5-ec2ccff69fa6.png)
![Screenshot_ourteampage](https://user-images.githubusercontent.com/98660924/166224201-f25ffb9f-904f-4f0b-98c6-a65f36c0d3d9.png)
![Screenshot_settingspage](https://user-images.githubusercontent.com/98660924/166224245-f59f3abf-dbe7-4327-9354-eee94bfae719.png)
![Screenshot_faqpage](https://user-images.githubusercontent.com/98660924/167757777-6d328641-1e25-400e-afe7-a760c44a139d.png)
![Screenshot_faqpage2](https://user-images.githubusercontent.com/98660924/167757789-031b599a-f4f1-46b1-87e8-8b9642d33986.png)


# Kamilla Nurgozhayeva (Ui/Ux Designer)
Working with presentation 
![image](https://user-images.githubusercontent.com/46282086/167258100-e6ce222a-a7f9-40d2-b7a3-b9705565c878.png)


# Rustem Bairamov (Frontend Developer)
Our team decided to make the entire web application interface in russian, and I finished translating all the pages
