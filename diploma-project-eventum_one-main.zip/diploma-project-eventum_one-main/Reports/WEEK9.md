# Ulan Orazaly (Project Manager)
* Creating visual mind map WBS
  https://planhammer.io/ 
![ulanorazalyreportweek9](https://user-images.githubusercontent.com/98660924/160383017-d8123f11-e6a5-4f91-81cf-9d106f5e20b7.jpeg)

# Bekzat Nauryzbayev (Backend Developer)
* Implementation of authorisation and registration, and the ability to change user data.
* ![Снимок экрана (2280)](https://user-images.githubusercontent.com/81714787/160386554-2f1b4e2a-13e5-4954-a342-952afd4e27a8.png)

# Meiirlan Serikbay (Full-stack Developer)
* Start CRUD development for child users. Creating Views

![Screenshot_childrencontroller](https://user-images.githubusercontent.com/98660924/159170728-afb4d940-f73a-46dd-85b4-a85fb62c5d25.png)
![Screenshot_childrencontroller1](https://user-images.githubusercontent.com/98660924/159170885-4b11d713-4203-4bca-b640-7a8d9f64806c.png)
![Screenshot_childrencontroller2](https://user-images.githubusercontent.com/98660924/159170893-fbd3f636-6c97-4d8d-ab17-3ebe13b3c7eb.png)

# Kamilla Nurgozhayeva (UX/UI-designer)
* Created a donation page for families going through hard times. For convenience, people can help send a donation to a family member's Kaspi card or through Robokassa

![image](https://user-images.githubusercontent.com/46282086/159216763-549fce21-5993-4f61-ad68-f30c0c500cbe.png)
![image](https://user-images.githubusercontent.com/46282086/159216790-fa91975a-d3ef-45b6-8a5e-229eae1fadd6.png)

# Rustem Bairamov (Frontend Developer)
* Created a Registration Page
* ![image](https://user-images.githubusercontent.com/47534213/160380470-c5710dcd-13f7-4b95-aa78-e1f8ebfd7654.png)
