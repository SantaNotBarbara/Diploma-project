# Ulan Orazaly (Project Manager)

# Bekzat Nauryzbayev (Backend Developer)
Testing of all controllers and speeds
# Meiirlan Serikbay (Full-stack Developer)
Testing of all interfaces for errors and Creating how to sell, how to buy lots
![Screenshot_howtobuy](https://user-images.githubusercontent.com/98660924/167830549-3c51b4b4-204e-414e-8415-899c70f6a500.png)
![Screenshot_howtobuy1](https://user-images.githubusercontent.com/98660924/167828030-78a09f3d-6a62-4a37-b1ff-3d0f5c003930.png)
![Screenshot_howtosell](https://user-images.githubusercontent.com/98660924/167828124-d0c50560-5fb7-49a2-b99b-a18c9c249ed2.png)
# Kamilla Nurgozhayeva (Ui/Ux Designer)
DOne with presentation. Prepare to final step
![image](https://user-images.githubusercontent.com/46282086/167258124-94463fcf-a4a4-4de9-96eb-06528461d4f4.png)

# Rustem Bairamov (Frontend Developer)
Fixed some errors in frontend of our web-app and created selling and buying lots pages
![image](https://user-images.githubusercontent.com/47534213/166267466-033449e5-b647-48f7-a2bf-9f74726b46d3.png)
![image](https://user-images.githubusercontent.com/47534213/166267478-b256ccb9-456a-465b-9f52-0a129ba6c7c9.png)
