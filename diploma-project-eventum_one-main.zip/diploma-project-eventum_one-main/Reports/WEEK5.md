# Ulan Orazaly (Project manager)
* Assigning tasks to each team member and checking all the main points for the implementation of the project.
# Bekzat Nauryzbayev (Backend Dev)
* Thinking of an architecture plan and select a database.
# Meiirlan Serikbay (Fullstack Dev)
* Participated in online meetings to discuss the construction of the project
# Kamilla Nurgozhayeva (Ui/Ux Designer)
*Designed warframes by using Balsamiq.Balsamiq Wireframes is a graphical user interface website wireframe builder application. It allows the designer to arrange pre-built widgets using a drag-and-drop WYSIWYG editor. The application is offered in a desktop version as well as a plug-in for Google Drive, Confluence and JIRA.
![image](https://user-images.githubusercontent.com/46282086/156812310-acf67f08-b4b7-41e1-8527-6b3c9430a469.png)
![image](https://user-images.githubusercontent.com/46282086/156812334-e383c4f5-ff32-4eaa-b5a4-8d93ee362374.png)
![image](https://user-images.githubusercontent.com/46282086/156812353-7f77150f-f607-489c-bfed-188c00fee1db.png)
![image](https://user-images.githubusercontent.com/46282086/156812381-06574eb1-2110-46b8-b055-9997e70c176d.png)
![image](https://user-images.githubusercontent.com/46282086/156812419-4f850366-40e4-44f6-8e94-4fb9c64715c6.png)
![image](https://user-images.githubusercontent.com/46282086/156812462-7b209f91-6f1b-4bf5-a901-e68cf0a13ee3.png)


# Rustem Bairamov (Frontend Dev)
* Planned tasks for the further project
