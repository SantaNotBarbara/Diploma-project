--CREATE DATABASE FamHelpV1;
--GO
--USE FamHelpV1;
GO
CREATE TABLE Cities (
    CitiId int NOT NULL PRIMARY KEY,
    CitiName varchar(255) NOT NULL
);
GO
CREATE TABLE Persons (
    Pk_Person_Id int NOT NULL PRIMARY KEY,
    LastName varchar(255) NOT NULL,
    FirstName varchar(255) NOT NULL,
	Phonenumber varchar(255) NOT NULL,
    Email varchar(255) NOT NULL,
	CreateDate datetime , 
	CitiId int FOREIGN KEY REFERENCES Cities(CitiId)
);
GO
CREATE TABLE Children (
    ChildId int NOT NULL PRIMARY KEY,
    LastName varchar(255) NOT NULL,
    FirstName varchar(255) NOT NULL,
	CreateDate datetime ,
	BirthDate datetime , 
	PersonId int FOREIGN KEY REFERENCES Persons(Pk_Person_Id)
);
GO
CREATE TABLE Lots (
    Pk_Lot_Id  int NOT NULL PRIMARY KEY,
    LotName varchar(255) NOT NULL,
    Description varchar(255) NOT NULL,
	Price int NOT NULL,
	PersonId int FOREIGN KEY REFERENCES Persons(Pk_Person_Id)
);
GO
CREATE TABLE Customer (
    CustomerId int NOT NULL PRIMARY KEY,
    Fk_Person_Id INT UNIQUE FOREIGN KEY REFERENCES Persons(Pk_Person_Id)
);
GO
CREATE TABLE ActionOrder (
    ActionID int NOT NULL PRIMARY KEY,
	Price int NOT NULL,
	CustomerId int FOREIGN KEY REFERENCES Customer(CustomerId),
    Fk_Person_Id INT UNIQUE FOREIGN KEY REFERENCES Lots(Pk_Lot_Id)
);